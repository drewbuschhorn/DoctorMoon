--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 27, true);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    password character varying(128) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 2, true);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, true);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 9, true);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Name: drmoon_networkgraph; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE drmoon_networkgraph (
    id integer NOT NULL,
    user_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    expired timestamp with time zone,
    unique_id text NOT NULL,
    graph_data text NOT NULL,
    shared boolean NOT NULL,
    complete boolean NOT NULL
);


ALTER TABLE public.drmoon_networkgraph OWNER TO postgres;

--
-- Name: drmoon_networkgraph_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE drmoon_networkgraph_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drmoon_networkgraph_id_seq OWNER TO postgres;

--
-- Name: drmoon_networkgraph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE drmoon_networkgraph_id_seq OWNED BY drmoon_networkgraph.id;


--
-- Name: drmoon_networkgraph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('drmoon_networkgraph_id_seq', 9, true);


--
-- Name: drmoon_userprofile; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE drmoon_userprofile (
    id integer NOT NULL,
    user_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    expired timestamp with time zone,
    request_code character varying(12) NOT NULL
);


ALTER TABLE public.drmoon_userprofile OWNER TO postgres;

--
-- Name: drmoon_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE drmoon_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drmoon_userprofile_id_seq OWNER TO postgres;

--
-- Name: drmoon_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE drmoon_userprofile_id_seq OWNED BY drmoon_userprofile.id;


--
-- Name: drmoon_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('drmoon_userprofile_id_seq', 2, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY drmoon_networkgraph ALTER COLUMN id SET DEFAULT nextval('drmoon_networkgraph_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY drmoon_userprofile ALTER COLUMN id SET DEFAULT nextval('drmoon_userprofile_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add user	3	add_user
8	Can change user	3	change_user
9	Can delete user	3	delete_user
10	Can add content type	4	add_contenttype
11	Can change content type	4	change_contenttype
12	Can delete content type	4	delete_contenttype
13	Can add session	5	add_session
14	Can change session	5	change_session
15	Can delete session	5	delete_session
16	Can add site	6	add_site
17	Can change site	6	change_site
18	Can delete site	6	delete_site
19	Can add log entry	7	add_logentry
20	Can change log entry	7	change_logentry
21	Can delete log entry	7	delete_logentry
22	Can add user profile	8	add_userprofile
23	Can change user profile	8	change_userprofile
24	Can delete user profile	8	delete_userprofile
25	Can add network graph	9	add_networkgraph
26	Can change network graph	9	change_networkgraph
27	Can delete network graph	9	delete_networkgraph
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, username, first_name, last_name, email, password, is_staff, is_active, is_superuser, last_login, date_joined) FROM stdin;
1	admin			admin@none.com	pbkdf2_sha256$10000$ZXuWhiaCorkb$ZOc8r5b47UnQts5PZbELKE/A622uAz8tUPdI7gFQiXk=	t	t	t	2012-08-19 22:28:43.930084-04	2012-08-19 22:22:19.505079-04
2	mike				pbkdf2_sha256$10000$SA1alw8w3VK1$LdtfaQ6CgLK3ALy+gzLtfa096N5PPNDJ0hPMxykdY0M=	f	t	f	2012-09-05 18:50:53.317036-04	2012-08-19 22:39:47.144955-04
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
1	2012-08-19 22:39:47.280286-04	1	3	2	mike	1	
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	permission	auth	permission
2	group	auth	group
3	user	auth	user
4	content type	contenttypes	contenttype
5	session	sessions	session
6	site	sites	site
7	log entry	admin	logentry
8	user profile	drmoon	userprofile
9	network graph	drmoon	networkgraph
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
964e6c39fbe060659096c14eab703ba1	NDY1Y2YxODJmZDJhNGFjMmI5NmQ1OWExNzMxMmQ5N2RkMjMzMWFjYTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAnUu\n	2012-09-03 20:46:05.941186-04
9bc6156cc859d42910a52d545e7c73d9	NDY1Y2YxODJmZDJhNGFjMmI5NmQ1OWExNzMxMmQ5N2RkMjMzMWFjYTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAnUu\n	2012-09-09 20:13:32.542285-04
ce29a814bce967651105edfc41fbfd41	NDY1Y2YxODJmZDJhNGFjMmI5NmQ1OWExNzMxMmQ5N2RkMjMzMWFjYTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAnUu\n	2012-09-19 18:50:53.333268-04
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Data for Name: drmoon_networkgraph; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY drmoon_networkgraph (id, user_id, created, modified, expired, unique_id, graph_data, shared, complete) FROM stdin;
1	2	2012-08-26 21:06:48.074619-04	2012-08-26 21:06:48.074619-04	\N	10.1371/journal.pmed.0020124	{\n  "nodes": [\n    {\n      "doi": "10.1371/journal.pmed.1000420", \n      "group": 0, \n      "name": "9::734211::10.1371/journal.pmed.1000420::1", \n      "path_index": 9, \n      "title": "Strengthening the Reporting of Genetic Risk Prediction Studies: The GRIPS Statement", \n      "is_original_author": 1, \n      "publication_date": 734211\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0020124", \n      "group": 0, \n      "name": "1::732188::10.1371/journal.pmed.0020124::1", \n      "path_index": 1, \n      "title": "Why Most Published Research Findings Are False", \n      "is_original_author": 1, \n      "publication_date": 732188\n    }, \n    {\n      "doi": "10.1371/journal.pctr.0010036", \n      "group": 0, \n      "name": "7::732632::10.1371/journal.pctr.0010036::1", \n      "path_index": 7, \n      "title": "Evolution and Translation of Research Findings: From Bench to Where", \n      "is_original_author": 1, \n      "publication_date": 732632\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0040297", \n      "group": 0, \n      "name": "9::732965::10.1371/journal.pmed.0040297::0", \n      "path_index": 9, \n      "title": "Strengthening the Reporting of Observational Studies in Epidemiology\\n          (STROBE): Explanation and Elaboration", \n      "is_original_author": 0, \n      "publication_date": 732965\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0020398", \n      "group": 0, \n      "name": "2::732279::10.1371/journal.pmed.0020398::1", \n      "path_index": 2, \n      "title": "Author's Reply", \n      "is_original_author": 1, \n      "publication_date": 732279\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0020386", \n      "group": 0, \n      "name": "4::732279::10.1371/journal.pmed.0020386::0", \n      "path_index": 4, \n      "title": "Power, Reliability, and Heterogeneous Results", \n      "is_original_author": 0, \n      "publication_date": 732279\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0040028", \n      "group": 0, \n      "name": "9::732734::10.1371/journal.pmed.0040028::0", \n      "path_index": 9, \n      "title": "Most Published Research Findings Are False\\u2014But a Little Replication Goes a Long Way", \n      "is_original_author": 0, \n      "publication_date": 732734\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0020361", \n      "group": 0, \n      "name": "5::732279::10.1371/journal.pmed.0020361::0", \n      "path_index": 5, \n      "title": "Truth, Probability, and Frameworks", \n      "is_original_author": 0, \n      "publication_date": 732279\n    }, \n    {\n      "doi": "10.1371/journal.pmed.1000217", \n      "group": 0, \n      "name": "13::733819::10.1371/journal.pmed.1000217::0", \n      "path_index": 13, \n      "title": "Guidance for Developers of Health Research Reporting Guidelines", \n      "is_original_author": 0, \n      "publication_date": 733819\n    }, \n    {\n      "doi": "10.1371/journal.pone.0004607", \n      "group": 0, \n      "name": "8::733463::10.1371/journal.pone.0004607::0", \n      "path_index": 8, \n      "title": "Decision-Making in Research Tasks with Sequential Testing", \n      "is_original_author": 0, \n      "publication_date": 733463\n    }, \n    {\n      "doi": "10.1371/journal.pmed.1001117", \n      "group": 0, \n      "name": "10::734435::10.1371/journal.pmed.1001117::1", \n      "path_index": 10, \n      "title": "STrengthening the Reporting of OBservational studies in Epidemiology \\u2013 Molecular Epidemiology (STROBE-ME): An Extension of the STROBE Statement", \n      "is_original_author": 1, \n      "publication_date": 734435\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0020395", \n      "group": 0, \n      "name": "6::732279::10.1371/journal.pmed.0020395::0", \n      "path_index": 6, \n      "title": "The Clinical Interpretation of Research", \n      "is_original_author": 0, \n      "publication_date": 732279\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0040215", \n      "group": 0, \n      "name": "1::732853::10.1371/journal.pmed.0040215::1", \n      "path_index": 1, \n      "title": "Why Most Published Research Findings Are False: Author's Reply to Goodman and Greenland", \n      "is_original_author": 1, \n      "publication_date": 732853\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0040168", \n      "group": 0, \n      "name": "3::732790::10.1371/journal.pmed.0040168::0", \n      "path_index": 3, \n      "title": "Why Most Published Research Findings Are False: Problems in the Analysis", \n      "is_original_author": 0, \n      "publication_date": 732790\n    }, \n    {\n      "doi": "10.1371/journal.pmed.0040296", \n      "group": 0, \n      "name": "11::732965::10.1371/journal.pmed.0040296::0", \n      "path_index": 11, \n      "title": "The Strengthening the Reporting of Observational Studies in Epidemiology\\n          (STROBE) Statement: Guidelines for Reporting Observational Studies", \n      "is_original_author": 0, \n      "publication_date": 732965\n    }, \n    {\n      "doi": "10.1371/journal.pone.0018362", \n      "group": 0, \n      "name": "8::734225::10.1371/journal.pone.0018362::1", \n      "path_index": 8, \n      "title": "Quantifying Selective Reporting and the Proteus Phenomenon for Multiple Datasets with Similar Bias", \n      "is_original_author": 1, \n      "publication_date": 734225\n    }, \n    {\n      "doi": "10.1371/journal.pmed.1000097", \n      "group": 0, \n      "name": "14::733609::10.1371/journal.pmed.1000097::0", \n      "path_index": 14, \n      "title": "Preferred Reporting Items for Systematic Reviews and Meta-Analyses: The PRISMA Statement", \n      "is_original_author": 0, \n      "publication_date": 733609\n    }\n  ], \n  "links": [\n    {\n      "source": 0, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 14, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 4, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 5, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 7, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 9, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 11, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 12, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 13, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 11, \n      "value": 1\n    }, \n    {\n      "source": 3, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 3, \n      "target": 8, \n      "value": 1\n    }, \n    {\n      "source": 3, \n      "target": 10, \n      "value": 1\n    }, \n    {\n      "source": 3, \n      "target": 14, \n      "value": 1\n    }, \n    {\n      "source": 3, \n      "target": 16, \n      "value": 1\n    }, \n    {\n      "source": 4, \n      "target": 11, \n      "value": 1\n    }, \n    {\n      "source": 4, \n      "target": 5, \n      "value": 1\n    }, \n    {\n      "source": 4, \n      "target": 7, \n      "value": 1\n    }, \n    {\n      "source": 8, \n      "target": 16, \n      "value": 1\n    }, \n    {\n      "source": 8, \n      "target": 10, \n      "value": 1\n    }, \n    {\n      "source": 9, \n      "target": 15, \n      "value": 1\n    }, \n    {\n      "source": 10, \n      "target": 14, \n      "value": 1\n    }, \n    {\n      "source": 12, \n      "target": 13, \n      "value": 1\n    }\n  ]\n}	f	t
2	2	2012-08-26 21:07:15.265538-04	2012-08-26 21:07:15.265538-04	\N	10.1371/journal.pntd.0000147	{\n  "nodes": [\n    {\n      "doi": "10.1371/journal.pntd.0001257", \n      "group": 0, \n      "name": "3::734351::10.1371/journal.pntd.0001257::0", \n      "path_index": 3, \n      "title": "Improving the Cost-Effectiveness of Visual Devices for the Control of Riverine Tsetse Flies, the Major Vectors of Human African Trypanosomiasis", \n      "is_original_author": 0, \n      "publication_date": 734351\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000715", \n      "group": 0, \n      "name": "5::733917::10.1371/journal.pntd.0000715::0", \n      "path_index": 5, \n      "title": "\\u201cPiggy-Backing\\u201d on Diagnostic Platforms Brings Hope to Neglected Diseases: The Case of Sleeping Sickness", \n      "is_original_author": 0, \n      "publication_date": 733917\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000865", \n      "group": 0, \n      "name": "1::734078::10.1371/journal.pntd.0000865::0", \n      "path_index": 1, \n      "title": "LAMP for Human African Trypanosomiasis: A Comparative Study of Detection Formats", \n      "is_original_author": 0, \n      "publication_date": 734078\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001008", \n      "group": 0, \n      "name": "3::734190::10.1371/journal.pntd.0001008::0", \n      "path_index": 3, \n      "title": "Sleeping Sickness Elimination in Sight: Time to Celebrate and Reflect, but Not Relax", \n      "is_original_author": 0, \n      "publication_date": 734190\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001572", \n      "group": 0, \n      "name": "1::734680::10.1371/journal.pntd.0001572::1", \n      "path_index": 1, \n      "title": "Loop-Mediated Isothermal Amplification Technology: Towards Point of Care Diagnostics", \n      "is_original_author": 1, \n      "publication_date": 734680\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000147", \n      "group": 0, \n      "name": "1::733078::10.1371/journal.pntd.0000147::1", \n      "path_index": 1, \n      "title": "Loop-Mediated Isothermal Amplification (LAMP) Method for Rapid Detection of Trypanosoma brucei rhodesiense", \n      "is_original_author": 1, \n      "publication_date": 733078\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001336", \n      "group": 0, \n      "name": "3::734400::10.1371/journal.pntd.0001336::1", \n      "path_index": 3, \n      "title": "Vegetation and the Importance of Insecticide-Treated Target Siting for Control of Glossina fuscipes fuscipes", \n      "is_original_author": 1, \n      "publication_date": 734400\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001249", \n      "group": 0, \n      "name": "2::734351::10.1371/journal.pntd.0001249::0", \n      "path_index": 2, \n      "title": "Using Detergent to Enhance Detection Sensitivity of African Trypanosomes in Human CSF and Blood by Loop-Mediated Isothermal Amplification (LAMP)", \n      "is_original_author": 0, \n      "publication_date": 734351\n    }\n  ], \n  "links": [\n    {\n      "source": 0, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 5, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 4, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 5, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 7, \n      "value": 1\n    }, \n    {\n      "source": 3, \n      "target": 5, \n      "value": 1\n    }, \n    {\n      "source": 4, \n      "target": 7, \n      "value": 1\n    }, \n    {\n      "source": 5, \n      "target": 7, \n      "value": 1\n    }\n  ]\n}	f	t
3	2	2012-08-26 21:07:34.769424-04	2012-08-26 21:07:34.769424-04	\N	10.1371/journal.pntd.0000435	{\n  "nodes": [\n    {\n      "doi": "10.1371/journal.pntd.0001008", \n      "group": 0, \n      "name": "4::734190::10.1371/journal.pntd.0001008::0", \n      "path_index": 4, \n      "title": "Sleeping Sickness Elimination in Sight: Time to Celebrate and Reflect, but Not Relax", \n      "is_original_author": 0, \n      "publication_date": 734190\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000632", \n      "group": 0, \n      "name": "3::733847::10.1371/journal.pntd.0000632::1", \n      "path_index": 3, \n      "title": "Prospects for the Development of Odour Baits to Control the Tsetse Flies Glossina tachinoides and G. palpalis s.l.", \n      "is_original_author": 1, \n      "publication_date": 733847\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000435", \n      "group": 0, \n      "name": "1::733539::10.1371/journal.pntd.0000435::1", \n      "path_index": 1, \n      "title": "Prospects for Developing Odour Baits To Control Glossina fuscipes spp., the Major Vector of Human African Trypanosomiasis", \n      "is_original_author": 1, \n      "publication_date": 733539\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001257", \n      "group": 0, \n      "name": "2::734351::10.1371/journal.pntd.0001257::1", \n      "path_index": 2, \n      "title": "Improving the Cost-Effectiveness of Visual Devices for the Control of Riverine Tsetse Flies, the Major Vectors of Human African Trypanosomiasis", \n      "is_original_author": 1, \n      "publication_date": 734351\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001226", \n      "group": 0, \n      "name": "1::734351::10.1371/journal.pntd.0001226::1", \n      "path_index": 1, \n      "title": "How Do Tsetse Recognise Their Hosts? The Role of Shape in the Responses of Tsetse (Glossina fuscipes and G. palpalis) to Artificial Hosts", \n      "is_original_author": 1, \n      "publication_date": 734351\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001332", \n      "group": 0, \n      "name": "6::734400::10.1371/journal.pntd.0001332::1", \n      "path_index": 6, \n      "title": "Towards an Optimal Design of Target for Tsetse Control: Comparisons of Novel Targets for the Control of Palpalis Group Tsetse in West Africa", \n      "is_original_author": 1, \n      "publication_date": 734400\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000474", \n      "group": 0, \n      "name": "5::733595::10.1371/journal.pntd.0000474::0", \n      "path_index": 5, \n      "title": "Improving the Cost-Effectiveness of Artificial Visual Baits for Controlling the Tsetse Fly Glossina fuscipes fuscipes", \n      "is_original_author": 0, \n      "publication_date": 733595\n    }\n  ], \n  "links": [\n    {\n      "source": 0, \n      "target": 2, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 2, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 4, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 3, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 4, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 5, \n      "target": 6, \n      "value": 1\n    }\n  ]\n}	f	t
4	2	2012-08-26 21:07:54.610844-04	2012-08-26 21:07:54.610844-04	\N	10.1371/journal.pntd.0000474	{\n  "nodes": [\n    {\n      "doi": "10.1371/journal.pntd.0000474", \n      "group": 0, \n      "name": "1::733595::10.1371/journal.pntd.0000474::1", \n      "path_index": 1, \n      "title": "Improving the Cost-Effectiveness of Artificial Visual Baits for Controlling the Tsetse Fly Glossina fuscipes fuscipes", \n      "is_original_author": 1, \n      "publication_date": 733595\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001336", \n      "group": 0, \n      "name": "1::734400::10.1371/journal.pntd.0001336::1", \n      "path_index": 1, \n      "title": "Vegetation and the Importance of Insecticide-Treated Target Siting for Control of Glossina fuscipes fuscipes", \n      "is_original_author": 1, \n      "publication_date": 734400\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001266", \n      "group": 0, \n      "name": "6::734358::10.1371/journal.pntd.0001266::1", \n      "path_index": 6, \n      "title": "Cryptic Diversity within the Major Trypanosomiasis Vector Glossina fuscipes Revealed by Molecular Markers", \n      "is_original_author": 1, \n      "publication_date": 734358\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001257", \n      "group": 0, \n      "name": "5::734351::10.1371/journal.pntd.0001257::1", \n      "path_index": 5, \n      "title": "Improving the Cost-Effectiveness of Visual Devices for the Control of Riverine Tsetse Flies, the Major Vectors of Human African Trypanosomiasis", \n      "is_original_author": 1, \n      "publication_date": 734351\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001008", \n      "group": 0, \n      "name": "7::734190::10.1371/journal.pntd.0001008::0", \n      "path_index": 7, \n      "title": "Sleeping Sickness Elimination in Sight: Time to Celebrate and Reflect, but Not Relax", \n      "is_original_author": 0, \n      "publication_date": 734190\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001226", \n      "group": 0, \n      "name": "3::734351::10.1371/journal.pntd.0001226::1", \n      "path_index": 3, \n      "title": "How Do Tsetse Recognise Their Hosts? The Role of Shape in the Responses of Tsetse (Glossina fuscipes and G. palpalis) to Artificial Hosts", \n      "is_original_author": 1, \n      "publication_date": 734351\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001332", \n      "group": 0, \n      "name": "4::734400::10.1371/journal.pntd.0001332::1", \n      "path_index": 4, \n      "title": "Towards an Optimal Design of Target for Tsetse Control: Comparisons of Novel Targets for the Control of Palpalis Group Tsetse in West Africa", \n      "is_original_author": 1, \n      "publication_date": 734400\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001661", \n      "group": 0, \n      "name": "2::734652::10.1371/journal.pntd.0001661::1", \n      "path_index": 2, \n      "title": "Optimizing the Colour and Fabric of Targets for the Control of the Tsetse Fly Glossina fuscipes fuscipes", \n      "is_original_author": 1, \n      "publication_date": 734652\n    }\n  ], \n  "links": [\n    {\n      "source": 0, \n      "target": 1, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 2, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 4, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 5, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 7, \n      "value": 1\n    }, \n    {\n      "source": 3, \n      "target": 4, \n      "value": 1\n    }\n  ]\n}	f	t
5	2	2012-08-26 21:08:23.744796-04	2012-08-26 21:08:23.744796-04	\N	10.1371/journal.pntd.0000632	{\n  "nodes": [\n    {\n      "doi": "10.1371/journal.pntd.0001332", \n      "group": 0, \n      "name": "4::734400::10.1371/journal.pntd.0001332::1", \n      "path_index": 4, \n      "title": "Towards an Optimal Design of Target for Tsetse Control: Comparisons of Novel Targets for the Control of Palpalis Group Tsetse in West Africa", \n      "is_original_author": 1, \n      "publication_date": 734400\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001336", \n      "group": 0, \n      "name": "1::734400::10.1371/journal.pntd.0001336::1", \n      "path_index": 1, \n      "title": "Vegetation and the Importance of Insecticide-Treated Target Siting for Control of Glossina fuscipes fuscipes", \n      "is_original_author": 1, \n      "publication_date": 734400\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001008", \n      "group": 0, \n      "name": "6::734190::10.1371/journal.pntd.0001008::0", \n      "path_index": 6, \n      "title": "Sleeping Sickness Elimination in Sight: Time to Celebrate and Reflect, but Not Relax", \n      "is_original_author": 0, \n      "publication_date": 734190\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001226", \n      "group": 0, \n      "name": "2::734351::10.1371/journal.pntd.0001226::1", \n      "path_index": 2, \n      "title": "How Do Tsetse Recognise Their Hosts? The Role of Shape in the Responses of Tsetse (Glossina fuscipes and G. palpalis) to Artificial Hosts", \n      "is_original_author": 1, \n      "publication_date": 734351\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001257", \n      "group": 0, \n      "name": "3::734351::10.1371/journal.pntd.0001257::1", \n      "path_index": 3, \n      "title": "Improving the Cost-Effectiveness of Visual Devices for the Control of Riverine Tsetse Flies, the Major Vectors of Human African Trypanosomiasis", \n      "is_original_author": 1, \n      "publication_date": 734351\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001491", \n      "group": 0, \n      "name": "5::734547::10.1371/journal.pntd.0001491::1", \n      "path_index": 5, \n      "title": "Standardizing Visual Control Devices for Tsetse Flies: West African Species Glossina tachinoides, G. palpalis gambiensis and G. morsitans submorsitans", \n      "is_original_author": 1, \n      "publication_date": 734547\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000632", \n      "group": 0, \n      "name": "1::733847::10.1371/journal.pntd.0000632::1", \n      "path_index": 1, \n      "title": "Prospects for the Development of Odour Baits to Control the Tsetse Flies Glossina tachinoides and G. palpalis s.l.", \n      "is_original_author": 1, \n      "publication_date": 733847\n    }\n  ], \n  "links": [\n    {\n      "source": 0, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 4, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 3, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 4, \n      "target": 6, \n      "value": 1\n    }, \n    {\n      "source": 5, \n      "target": 6, \n      "value": 1\n    }\n  ]\n}	f	t
6	2	2012-08-26 21:09:06.578907-04	2012-08-26 21:09:06.578907-04	\N	10.1371/journal.pntd.0000471	{\n  "nodes": [\n    {\n      "doi": "10.1371/journal.pntd.0001438", \n      "group": 0, \n      "name": "4::734512::10.1371/journal.pntd.0001438::1", \n      "path_index": 4, \n      "title": "Diagnostic Accuracy of Molecular Amplification Tests for Human African Trypanosomiasis\\u2014Systematic Review", \n      "is_original_author": 1, \n      "publication_date": 734512\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000471", \n      "group": 0, \n      "name": "1::733735::10.1371/journal.pntd.0000471::1", \n      "path_index": 1, \n      "title": "Improved Models of Mini Anion Exchange Centrifugation Technique (mAECT) and Modified Single Centrifugation (MSC) for Sleeping Sickness Diagnosis and Staging", \n      "is_original_author": 1, \n      "publication_date": 733735\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000972", \n      "group": 0, \n      "name": "3::734190::10.1371/journal.pntd.0000972::1", \n      "path_index": 3, \n      "title": "Diagnostic Accuracy of PCR in gambiense Sleeping Sickness Diagnosis, Staging and Post-Treatment Follow-Up: A 2-year Longitudinal Study", \n      "is_original_author": 1, \n      "publication_date": 734190\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0001691", \n      "group": 0, \n      "name": "2::734666::10.1371/journal.pntd.0001691::1", \n      "path_index": 2, \n      "title": "Untreated Human Infections by Trypanosoma brucei gambiense Are Not 100% Fatal", \n      "is_original_author": 1, \n      "publication_date": 734666\n    }, \n    {\n      "doi": "10.1371/journal.pntd.0000917", \n      "group": 0, \n      "name": "1::734127::10.1371/journal.pntd.0000917::1", \n      "path_index": 1, \n      "title": "Revisiting the Immune Trypanolysis Test to Optimise Epidemiological Surveillance and Control of Sleeping Sickness in West Africa", \n      "is_original_author": 1, \n      "publication_date": 734127\n    }\n  ], \n  "links": [\n    {\n      "source": 0, \n      "target": 1, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 2, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 4, \n      "value": 1\n    }\n  ]\n}	f	t
7	2	2012-08-26 21:09:21.36288-04	2012-08-26 21:09:21.36288-04	\N	10.1371/journal.pgen.0020047	{\n  "nodes": [\n    {\n      "doi": "10.1371/journal.pgen.0020063", \n      "group": 0, \n      "name": "2::732429::10.1371/journal.pgen.0020063::0", \n      "path_index": 2, \n      "title": "Genome Network and FANTOM3: Assessing the Complexity of the Transcriptome", \n      "is_original_author": 0, \n      "publication_date": 732429\n    }, \n    {\n      "doi": "10.1371/journal.pgen.0020047", \n      "group": 0, \n      "name": "1::732429::10.1371/journal.pgen.0020047::1", \n      "path_index": 1, \n      "title": "Complex Loci in Human and Mouse Genomes", \n      "is_original_author": 1, \n      "publication_date": 732429\n    }, \n    {\n      "doi": "10.1371/journal.pone.0001486", \n      "group": 0, \n      "name": "3::733064::10.1371/journal.pone.0001486::0", \n      "path_index": 3, \n      "title": "A Novel RNA Transcript with Antiapoptotic Function Is Silenced in Fragile X Syndrome", \n      "is_original_author": 0, \n      "publication_date": 733064\n    }, \n    {\n      "doi": "10.1371/journal.pone.0013177", \n      "group": 0, \n      "name": "1::734049::10.1371/journal.pone.0013177::1", \n      "path_index": 1, \n      "title": "RNAi Screen Indicates Widespread Biological Function for Human Natural Antisense Transcripts", \n      "is_original_author": 1, \n      "publication_date": 734049\n    }\n  ], \n  "links": [\n    {\n      "source": 0, \n      "target": 1, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 2, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 3, \n      "value": 1\n    }\n  ]\n}	f	t
8	2	2012-08-26 21:09:44.868526-04	2012-08-26 21:09:44.868526-04	\N	10.1371/journal.pone.0000787	{\n  "nodes": [\n    {\n      "doi": "10.1371/journal.pone.0000787", \n      "group": 0, \n      "name": "1::732917::10.1371/journal.pone.0000787::1", \n      "path_index": 1, \n      "title": "Insights from Amphioxus into the Evolution of Vertebrate Cartilage", \n      "is_original_author": 1, \n      "publication_date": 732917\n    }, \n    {\n      "doi": "10.1371/journal.pone.0022474", \n      "group": 0, \n      "name": "1::734340::10.1371/journal.pone.0022474::1", \n      "path_index": 1, \n      "title": "A New Mechanistic Scenario for the Origin and Evolution of Vertebrate Cartilage", \n      "is_original_author": 1, \n      "publication_date": 734340\n    }, \n    {\n      "doi": "10.1371/journal.pgen.1000025", \n      "group": 0, \n      "name": "2::733122::10.1371/journal.pgen.1000025::0", \n      "path_index": 2, \n      "title": "Evolution of a Core Gene Network for Skeletogenesis in Chordates", \n      "is_original_author": 0, \n      "publication_date": 733122\n    }\n  ], \n  "links": [\n    {\n      "source": 0, \n      "target": 1, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 2, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 2, \n      "value": 1\n    }\n  ]\n}	f	t
9	2	2012-08-26 23:03:23.19637-04	2012-08-26 23:03:23.19637-04	\N	10.1371/journal.pone.0008155	{\n  "nodes": [\n    {\n      "doi": "10.1371/journal.pgen.1001290", \n      "group": 0, \n      "name": "2::734171::10.1371/journal.pgen.1001290::0", \n      "path_index": 2, \n      "title": "Quantitative Models of the Mechanisms That Control Genome-Wide Patterns of Transcription Factor Binding during Early Drosophila Development", \n      "is_original_author": 0, \n      "publication_date": 734171\n    }, \n    {\n      "doi": "10.1371/journal.pgen.1002266", \n      "group": 0, \n      "name": "2::734430::10.1371/journal.pgen.1002266::0", \n      "path_index": 2, \n      "title": "Zelda Binding in the Early Drosophila melanogaster Embryo Marks Regions Subsequently Activated at the Maternal-to-Zygotic Transition", \n      "is_original_author": 0, \n      "publication_date": 734430\n    }, \n    {\n      "doi": "10.1371/journal.pone.0008155", \n      "group": 0, \n      "name": "1::733742::10.1371/journal.pone.0008155::1", \n      "path_index": 1, \n      "title": "A Biophysical Model for Analysis of Transcription Factor Interaction and Binding Site Arrangement from Genome-Wide Binding Data", \n      "is_original_author": 1, \n      "publication_date": 733742\n    }, \n    {\n      "doi": "10.1371/journal.pgen.1002769", \n      "group": 0, \n      "name": "2::734675::10.1371/journal.pgen.1002769::1", \n      "path_index": 2, \n      "title": "Preferential Genome Targeting of the CBP Co-Activator by Rel and Smad Proteins in Early Drosophila melanogaster Embryos", \n      "is_original_author": 1, \n      "publication_date": 734675\n    }, \n    {\n      "doi": "10.1371/journal.pcbi.1002064", \n      "group": 0, \n      "name": "1::734297::10.1371/journal.pcbi.1002064::1", \n      "path_index": 1, \n      "title": "Towards an Evolutionary Model of Transcription Networks", \n      "is_original_author": 1, \n      "publication_date": 734297\n    }\n  ], \n  "links": [\n    {\n      "source": 0, \n      "target": 1, \n      "value": 1\n    }, \n    {\n      "source": 0, \n      "target": 2, \n      "value": 1\n    }, \n    {\n      "source": 1, \n      "target": 3, \n      "value": 1\n    }, \n    {\n      "source": 2, \n      "target": 4, \n      "value": 1\n    }\n  ]\n}	f	t
\.


--
-- Data for Name: drmoon_userprofile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY drmoon_userprofile (id, user_id, created, modified, expired, request_code) FROM stdin;
1	1	2012-08-19 22:22:19.641013-04	2012-08-19 22:22:19.641044-04	\N	00x284785467
2	2	2012-08-19 22:39:47.278069-04	2012-08-19 22:39:47.278099-04	\N	00x991356130
\.


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_model_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: drmoon_networkgraph_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY drmoon_networkgraph
    ADD CONSTRAINT drmoon_networkgraph_pkey PRIMARY KEY (id);


--
-- Name: drmoon_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY drmoon_userprofile
    ADD CONSTRAINT drmoon_userprofile_pkey PRIMARY KEY (id);


--
-- Name: drmoon_userprofile_request_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY drmoon_userprofile
    ADD CONSTRAINT drmoon_userprofile_request_code_key UNIQUE (request_code);


--
-- Name: drmoon_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY drmoon_userprofile
    ADD CONSTRAINT drmoon_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: drmoon_networkgraph_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX drmoon_networkgraph_user_id ON drmoon_networkgraph USING btree (user_id);


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_728de91f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_728de91f FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: drmoon_networkgraph_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY drmoon_networkgraph
    ADD CONSTRAINT drmoon_networkgraph_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: drmoon_userprofile_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY drmoon_userprofile
    ADD CONSTRAINT drmoon_userprofile_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_3cea63fe; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_3cea63fe FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_831107f1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_831107f1 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_f2045483; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_f2045483 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

